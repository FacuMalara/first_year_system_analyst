"""
Ejercicio 5.15 (Base de peliculas)
El programa debe:

Simular una base de datos de peliculas y series con la capacidad 
de agregar, buscar, eliminar y filtrar peliculas y series.
Debe comenzar con las siguientes peliculas y series en un diccionario:
base = {
    "peliculas" : ["El hombre araña", "Los vengadores" , "Los vengadores 2"],
    "series" : ["prision break", "la casa de papel" , "los simpsons"]
        }
Contar con 5 funciones disponibles en el menu:
-Mostrar por pantalla en formato vertical la lista de peliculas o 
series disponibles.
-Agregar nuevas peliculas o series (que no esten) en la base.
-Eliminar peliculas o series de la base.
-Mostrar segun requiera el usuario la lista de peliculas desde un 
punto a otro (ej el usuario quiere ver de la 2° a la 4° una lista ).
-Buscar peliculas o series que contengan una palabra requerida por 
el usuario. (ej. input("el"), se liste las peliculas que contengan la
palabra "el").
"""

from functions import *


def menu():

    base = {
        "peliculas": ["El hombre araña", "Los vengadores", "Los vengadores 2"],
        "series": ["prision break", "la casa de papel", "los simpsons"]
    }
    while True:
        opcion = input("""Bienvenido al menu:
1. Ver lista de peliculas y series.
2. Agregar nuevas peliculas o series.
3. Eliminar peliculas o series.
4. Mostrar segun requieraa el usuario la lista de peliculas.
5. Buscar peliculas o series que contengan una palabra requerida por el usuario.
6. Salir
                    
Ingrese opcion: """)

        match opcion:
            case "1":
                mostrar_lista(base)
            case "2":
                base = agregar_nuevas(base)
            case "3":
                base = eliminar_cosa(base)
            case "4":
                muestra_manual(base)
            case "5":
                busca_por_palabra(base)
            case "6":
                print("Saliendo")
                return


if __name__ == "__main__":
    menu()
