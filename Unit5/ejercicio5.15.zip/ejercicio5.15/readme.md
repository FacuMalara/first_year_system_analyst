Ejercicio 5.15 (Base de peliculas)
El programa debe:

Simular una base de datos de peliculas y series con la capacidad de agregar, buscar, eliminar y filtrar peliculas y series.
Debe comenzar con las siguientes peliculas y series en un diccionario:
base = {
    "peliculas" : ["El hombre araña", "Los vengadores" , "Los vengadores 2"],
    "series" : ["prision break", "la casa de papel" , "los simpsons"]
        }
Contar con 5 funciones disponibles en el menu:
Mostrar por pantalla en formato vertical la lista de peliculas o series disponibles.
Agregar nuevas peliculas o series (que no esten) en la base.
Eliminar peliculas o series de la base.
Mostrar segun requiera el usuario la lista de peliculas desde un punto a otro (ej el usuario quiere ver de la 2° a la 4° una lista ).
Buscar peliculas o series que contengan una palabra requerida por el usuario. (ej. input("el"), se liste las peliculas que contengan la palabra "el").