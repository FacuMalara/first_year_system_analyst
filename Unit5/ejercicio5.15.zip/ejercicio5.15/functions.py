def pedir_numero(texto_para_pedir):
    while True:
        try:
            numero1, numero2 = input(texto_para_pedir), input()
            if numero1.isnumeric() and numero2.isnumeric():
                nuevo_numero1 = int(numero1)
                nuevo_numero2 = int(numero2)
                return nuevo_numero1, nuevo_numero2
            else:
                print("Ingreso incorrecto")
        except ValueError as e:
            print(f"Error {e}")


def mostrar_lista(base):
    for clave, lista in base.items():
        print(f"\n{clave}:\n ")
        for elemento in lista:
            print(f"{elemento}")
    print("\n")


def agregar_nuevas(base):
    print("Que desea agregar?")
    opcion = input("pelicula/serie: ").lower()
    if opcion == "pelicula":
        base["peliculas"].append(
            input("Ingrese una pelicula: ").lower())
        return base
    elif opcion == "serie":
        base["series"].append(
            input("Ingrese una serie: ").lower())
        return base
    else:
        print("Opcion incorrecta")
    print("Si no aparece actualizada no ingreso correctamente o la pelicula/serie ya existe")


def eliminar_cosa(base):
    cosa_a_eliminar = input("Ingrese pelicula o serie a eliminar: ").lower()
    if cosa_a_eliminar in base["peliculas"]:
        base["peliculas"].remove(cosa_a_eliminar)
        return base
    elif cosa_a_eliminar in base["series"]:
        base["series"].remove(cosa_a_eliminar)
        return base
    else:
        print("No se encontro el objeto")


def muestra_manual(base):
    opcion = input("Elija a que lista acceder, series/peliculas: ")
    if opcion == "peliculas":
        inicio, fin = pedir_numero("Ingrese dos numeros: ")
        for pelicula in base["peliculas"]:
            if pelicula == base["peliculas"][inicio-1]:
                # no le resto a fin porque ese numero indica la cantidad de elementos que quiero imprimir a partir de inicio - 1, no es una posicion
                print(base["peliculas"][inicio-1:fin])
    elif opcion == "series":
        inicio, fin = pedir_numero("Ingrese dos numeros: ")
        for pelicula in base["series"]:
            if pelicula == base["series"][inicio-1]:
                print(base["series"][inicio-1:fin])
    else:
        print("Opcion invalida")


def busca_por_palabra(base):
    opcion = input("Elija a que lista acceder, peliculas/series: ")
    if opcion == "peliculas":
        palabra = input("Ingrese una palabra: ").lower()
        for pelicula in base["peliculas"]:
            if palabra in pelicula:
                print(f"La pelicula es: {pelicula}")
    elif opcion == "series":
        palabra = input("Ingrese una palabra: ").lower()
        for serie in base["series"]:
            if palabra in serie:
                print(f"La serie es: {serie}")
    else:
        print("Opcion incorrecta")
