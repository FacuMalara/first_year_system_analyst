"""
Crear una clase padre Vehiculo:
*   Constructor debe incluir los atributos (patente,marca,año,origen)
*   Crear metodos para esta clase de:
    1.  Presentarse (patente,marca,año,origen)
    2.  Indicar tipos de vehiculo(Clases heredadas)
    3.  Metodos que luego modificarán las clases hijas. Acelerar, Retroceder, obtener_velocidad, setear_velocidad
Crear 3 clases que hereden de la clase padre Vehiculos, con un atributo en particular para cada una
1.   Particular
2.   PickUp
3.   Deportivo"""


class Car:
    def __init__(self, license_plate, brand, year, origin, speed):
        self.license_plate = license_plate
        self.brand = brand
        self.year = year
        self.origin = origin
        self.speed = speed

    def present(self):
        print(
            f"This is a car from the brand {self.brand}, year {self.year}, has this license plate {self.license_plate}, manufactured on {self.origin} and max speed {self.speed}km/h")

    def types(self):
        print(f"This is a car of type: {type(self).__name__}")

    def speed_up(self, accelerator):
        self.speed = self.speed * accelerator
        print(f"New speed: {self.speed}")

    def reverse(self, accelerator):
        self.speed = self.speed / accelerator
        print(f"New speed: {self.speed}")

    def get_speed(self):
        while True:
            try:
                speed = input("At which speed(int): ")
                if speed.isnumeric():
                    speed = int(speed)
                    return speed
                else:
                    print("Incorrect")
            except ValueError as e:
                print(f"Invalid income {e}")

    def set_speed(self):
        while True:
            try:
                speed = input("Set the new speed(int): ")
                if speed.isnumeric():
                    speed = int(speed)
                    self.speed = speed
                    print(f"New speed is set: {self.speed}")
                    break
                else:
                    print("Incorrect")
            except ValueError as e:
                print(f"Invalid income {e}")


class Particular(Car):
    def __init__(self, license_plate, brand, year, origin, speed, seats):
        super().__init__(license_plate, brand, year, origin, speed)
        self.seats = seats


class PickUp(Car):
    def __init__(self, license_plate, brand, year, origin, speed, gas_type):
        super().__init__(license_plate, brand, year, origin, speed)
        self.gas_type = gas_type


class SportsCar(Car):
    def __init__(self, license_plate, brand, year, origin, speed, turbo):
        super().__init__(license_plate, brand, year, origin, speed)
        self.turbo = turbo
