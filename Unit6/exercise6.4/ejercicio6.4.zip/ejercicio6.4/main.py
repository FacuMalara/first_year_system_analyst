from gestorautos import *


def main():
    obj_gestor = CarManager()
    while True:
        menu = """
1. Crear auto, indicando tipo de auto y guardar en una lista
2. Listar autos (presentandolos), indicando tipo de Vehiculo.
3. Cambiar velocidad de un Vehiculo
4. Calcular tiempo de viaje de un Vehiculo en una cant de Km pasados por parametro (tiempo = Km / Velocidad)
5. Salir

Insert option: 
"""
        opcion = input(menu)
        match opcion:
            case '1':
                obj_gestor.create_car()
            case '2':
                obj_gestor.list_cars()
            case '3':
                obj_gestor.change_speed()
            case '4':
                obj_gestor.calculate()
            case '5':
                print("saliendo")
                return
            case _:
                print('opcion incorrecta')


if __name__ == "__main__":
    main()
