###**Ejercicio 6.5**
Crear una clase padre Computadoras:
*   Constructor debe incluir los atributos (id_modelo,listaPerifericos,SO,marca)
*   Crear metodos para esta clase de:
    1.  Presentarse (id_modelo,listaPerifericos,SO)
    2.  Indicar tipo de Computadora (Clases heredadas)
    3.  Metodos que luego modificarán las clases hijas. agregar_perifericos,CambiarSO

Crear 2 clases que hereden de la clase padre Computadoras, con un atributo en particular para cada una
1.   Escritorio
2.   Notebook

Crear clase GestorComputadora que cuente con las siguientes funciones para un menu
1.   Crear Computadora, indicando tipo y guardar en una lista. Verificando marca y SO de una lista
2.   Listar Computadoras (presentandolos), indicando tipo.
3.   Cambiar SO de una Computadora, verificando una lista de SO disponibles
4.   Listar perifericos