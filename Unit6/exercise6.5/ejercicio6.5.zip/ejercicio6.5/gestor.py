"""
Crear clase GestorComputadora que cuente con las siguientes funciones para un menu
1.   Crear Computadora, indicando tipo y guardar en una lista. Verificando marca y SO de una lista
2.   Listar Computadoras (presentandolos), indicando tipo.
3.   Cambiar SO de una Computadora, verificando una lista de SO disponibles
4.   Listar perifericos"""
from clase import *


class GestorComputadora:
    # Atributos de clase
    lista_marcas = ['dell', 'hp', 'apple']
    lista_SO = ['macOS', 'linux', 'windows']

    def __init__(self):
        self.lista_computadoras: list[Computadora] = []

    def pedir_tipo(self):
        while True:
            print('------ Posibles pcs a crear ------')
            tipo_clase = input('indique tipo de la pc: ')
            for i in Computadora.__subclasses__():
                if i.__name__ == tipo_clase:
                    # TAREA: buscar mejor forma
                    return tipo_clase
            print('Esa clase no existe')

    def pedir_marca_SO(self, objeto_a_pedir, lista_objetos):
        while True:
            print(f'------ Posibles {objeto_a_pedir} a crear ------')
            for obj in lista_objetos:
                print(f'- {obj}')
            obj = input(f'indique el/la {objeto_a_pedir}: ')
            if obj in lista_objetos:
                return obj
            else:
                print(f'Esa/ese {objeto_a_pedir} no existe')

    def pedir_lista_perifericos(self):
        lista_perifericos = []
        while True:
            periferico = input(
                'indique un periferico (exit para terminar): ')
            if periferico == 'exit':
                return lista_perifericos
            else:
                lista_perifericos.append(periferico)

    def crear_computadora(self):
        tipo_clase = self.pedir_tipo()
        id = input('Indique el id: ')
        marca = self.pedir_marca_SO('marca', self.lista_marcas)
        so = self.pedir_marca_SO('SO', self.lista_SO)
        lista_perisfericos = self.pedir_lista_perifericos()
        if tipo_clase == 'Notebook':
            peso = input('Indique el peso: ')
            object_pc = Notebook(id, lista_perisfericos, so, marca, peso)
        if tipo_clase == 'Escritorio':
            cables = input('Indique la cant de cables:')
            object_pc = Escritorio(id, lista_perisfericos, so, marca, cables)

        self.lista_computadoras.append(object_pc)

    def listar_computadoras(self):
        for pc in self.lista_computadoras:
            pc.get_tipo()

    def cambiar_SO(self):
        id = input("Ingrese id de la computadora: ")
        for computadora in self.lista_computadoras:
            if computadora.id_modelo == id:
                nuevo_SO = self.pedir_marca_SO("SO", self.lista_SO)
                computadora.SO = nuevo_SO
                computadora.get_tipo()
            else:
                print("La computadora no existe")

    def listar_perifericos(self):
        print("----Perifericos----")
        contador = 0
        for computadora in self.lista_computadoras:
            contador = +1
            print(
                f"Computadora {contador}- Id:{computadora.id_modelo}\nPerifericos:")
            for periferico in computadora.lista_perifericos:
                print(f"{contador}. {periferico} ")


gestor_test = GestorComputadora()
gestor_test.crear_computadora()
gestor_test.listar_computadoras()
