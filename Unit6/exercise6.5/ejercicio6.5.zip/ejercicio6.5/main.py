from gestor import *


def menu():
    # instancio un objeto de gestor peliculas para usar sus metodos
    obj_gestor = GestorComputadora()
    while True:
        menu = """
1. Crear una computadora y guardar el objeto en una lista de computadoras.
2. Listar computadora.
3. Cambiar SO.
4. Listar perifericos
5. Salir
opcion: """
        opcion = input(menu)
        match opcion:
            case '1':
                obj_gestor.crear_computadora()
            case '2':
                obj_gestor.listar_computadoras()
            case '3':
                obj_gestor.cambiar_SO()
            case '4':
                obj_gestor.listar_perifericos()
            case '5':
                print("saliendo")
                return
            case _:
                print('opcion incorrecta')


if __name__ == "__main__":
    menu()
