class Persona:

    def __init__(self, nombre, apellido, edad, ciudad_residencia) -> None:
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.ciudad_residencia = ciudad_residencia

    def presentar_persona(self):
        print(
            f"""Soy {self.nombre} {self.apellido}, tengo {self.edad} años
y vivo en {self.ciudad_residencia}""")

    def grupos_por_edad(self):
        if self.edad <= 14:
            print("Es niño")
        elif self.edad <= 22:
            print("Es adolescente")
        elif self.edad <= 30:
            print("Es joven")
        elif self.edad <= 50:
            print("Es adulto")
        elif self.edad <= 120:
            print("Es viejo")
