Ejercicio 6.1
Crear una clase de Persona:

Cuyo constructutor debe inicializar los atributos nombre, apellido, edad, ciudad_de_residencia
Se deben crear dos metodos en la clase:
Presentarse que la persona indique: Soy {nombre} {apellido}, tengo {edad} años y vivo en {ciudad de residencia}
Indique segun la edad de la persona si esta es: niño (0 a 14), adolescente (14 a 22), joven (22 a 30), mayor(30 a 50), viejo(50 a 120)
Crear una funcion que permita agregar objectos a una lista