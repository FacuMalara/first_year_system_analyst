from classes import *
from objects import *

persona1.presentar_persona()
persona1.grupos_por_edad()
