from classes import *


persona1 = Persona(nombre="facu", apellido="akalabastrungen",
                   edad=25, ciudad_residencia="carlos paz")
