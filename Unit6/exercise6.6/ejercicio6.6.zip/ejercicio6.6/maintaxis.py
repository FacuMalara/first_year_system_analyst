from gestortaxis import *


def main():

    obj_manager = TaxisManager()

    while True:
        menu = input("""
1. Crear instancias de choferes y guardarlos en una lista de choferes
2. Crear instancias de Autos (verificando que haya choferes para ese auto) y guardarlos en una lista de autos
3. Modificar el chofer de un auto
4. Modificar el lugar de residencia del chofer indicando su nombre
5. imprmiir lista de choferes (con toda su informacion)
6. imprimir lista de autos (con toda su informacions)
7. Salir

Insert option: 
""")

        match menu:
            case '1':
                obj_manager.create_drivers()
            case '2':
                obj_manager.create_taxis()
            case '3':
                obj_manager.modify_driver()
            case '4':
                obj_manager.modify_residence()
            case '5':
                obj_manager.print_drivers_list()
            case "6":
                obj_manager.print_car_list()
            case "7":
                print("Quiting")
                return
            case _:
                print('Incorrect income')


if __name__ == "__main__":
    main()
