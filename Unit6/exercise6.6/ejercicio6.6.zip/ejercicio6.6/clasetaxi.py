"""Ejercicio 6.6 (Empresa de Taxis)
Simular una empresa de taxis que cuente con dos clases: Autos y Chofer

La Clase auto tiene los atributos (patente, modelo, año, marca, nombre_Chofer (objeto clase Choferes))

La Clase Chofer tiene los atributos (nombre, apellido, dni, fecha nacimiento, Residencia)"""


class Driver:
    def __init__(self, drivers_name, last_name, identification, birth_date, residence):
        self.drivers_name = drivers_name
        self.last_name = last_name
        self.identification = identification
        self.birth_date = birth_date
        self.residence = residence


class Taxis:
    def __init__(self, license_plate, model, year, brand, drivers_name: Driver):
        self.license_plate = license_plate
        self.model = model
        self.year = year
        self.brand = brand
        self.drivers_name = drivers_name
