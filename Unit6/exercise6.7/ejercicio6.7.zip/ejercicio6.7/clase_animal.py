"""
La Clase Animales tiene los atributos (nombre, tipo_animal, 
fecha_nacimiento, encargado_cuidar (Nombre de objeto empleado))

Crear 3 clases que hereden de animal segun su sector del zoologico)
Animales en jaulas.
Animales sueltos.
Animales en el agua
La Clase Empleados tiene los atributos (legajo, nombre, apellido, lista_animales_a_cuidar
(clase animal))
"""


class Animal:
    def __init__(self, nombre, tipo_animal, fecha_nacimiento, encargado_cuidar):
        self.nombre = nombre
        self.tipo_animal = tipo_animal
        self.fecha_nacimiento = fecha_nacimiento
        self.encargado_cuidar = encargado_cuidar

    def cambiar_encargado(self, nuevo_encargado):
        self.encargado_cuidar = nuevo_encargado


class AnimalJaula(Animal):
    pass


class AnimalSuelto(Animal):
    pass


class AnimalAcuatico(Animal):
    pass

# anima_auc = AnimalAcuatico('test','test','test',Empleado())
