from gestor_animals import *


def main():

    obj_manager = GestorZoologico()

    while True:
        menu = input("""
1. Crear instancias de animales (se puede elegir entre los tres sectores)  y guardarlos en una lista
2. Crear instancia de Empleados y guardarlos en una lista
        * Los empleados se les pueden asignar animales luego, los animales al crearlos en el sistema tienen q contar siosi con un encargado
3. Asignar a un empleado un animal a cuidar
4. Cambiar de encargado un animal
5. imprmiir lista de animales (con toda su informacions)
6. imprimir lista de Empleados (con toda su informacions)
7. Salir

Insert option: 
""")

        match menu:
            case '1':
                obj_manager.crear_animal()
            case '2':
                obj_manager.crear_encargado()
            case '3':
                obj_manager.asignar_animal()
            case '4':
                obj_manager.cambiar_de_encargado_al_animal()
            case '5':
                obj_manager.imprimir_lista_animales()
            case "6":
                obj_manager.imprimir_lista_empleados()
            case "7":
                print("Saliendo")
                return
            case _:
                print('Ingreso incorrecto')


if __name__ == "__main__":
    main()
