"""
Contar con 6 funciones disponibles en el menu (estas funciones deben estar incluidas en 
una clase llamada GestorZoologico):

Crear instancias de animales (se puede elegir entre los tres sectores) y guardarlos en una lista
Crear instancia de Empleados y guardarlos en una lista
Los empleados se les pueden asignar animales luego, los animales al crearlos en el sistema 
tienen q contar si o si con un encargado

Asignar a un empleado un animal a cuidar
Cambiar de encargado un animal
imprmiir lista de animales (con toda su informacions)
imprimir lista de Empleados (con toda su informacions)
Se deben crear los metodos correspondientes para las funciones del menu en las clases correspondientes

Gestionar posibles errores

Estructurar el programa a criterio propio
"""

from clase_animal import *
from clase_empleado import *


class GestorZoologico:
    def __init__(self):
        self.lista_empleados: list[Empleado] = []
        self.lista_animales: list[Animal] = []

    def crear_animal(self):
        nombre = input("Nombre del animal: ")
        tipo_animal = input("Tipo de animal: ")
        fecha_nacimiento = input("Fecha de nacimiento: ")
        opcion = input("Tiene encargado? SI/NO: ")
        if opcion == "no":
            encargado_cuidar = self.crear_encargado()
        elif opcion == "si":
            encargado_cuidar = input("Ingrese legajo del encargado: ")
            for empleado in self.lista_empleados:
                if empleado.legajo == encargado_cuidar:
                    encargado_cuidar = empleado
                else:
                    print("El empleado no existe")
        else:
            print("Ingreso invalido")
        animal = Animal(nombre, tipo_animal,
                        fecha_nacimiento, encargado_cuidar)
        for empleado in self.lista_empleados:
            if encargado_cuidar == empleado:
                encargado_cuidar.lista_animales_a_cuidar.append(animal)
        self.lista_animales.append(animal)

    def crear_encargado(self):
        legajo = input("Legajo: ")
        nombre = input("Nombre: ")
        apellido = input("Apellido: ")
        empleado = Empleado(legajo, nombre, apellido)
        self.lista_empleados.append(empleado)
        return empleado

    def asignar_animal(self):
        empleado_ = self.encontrar_empleado(
            "Ingrese el Legajo del empleado al que se le desea asignar un animal: ")
        if not empleado_:
            print("El legajo ingresado no corresponde a un empleado de la lista")
        else:
            animal_ = self.encontrar_animal("Ingrese animal a cuidar: ")
            if not animal_:
                print("El animal no se encuentra en la lista")
            else:
                empleado_.lista_animales_a_cuidar.append(animal_)

    def encontrar_empleado(self, texto):
        legajo_empleado = input(texto)
        for empleado in self.lista_empleados:
            if empleado.legajo == legajo_empleado:
                return empleado

    def encontrar_animal(self, texto):
        nombre_animal = input(texto)
        for animal in self.lista_animales:
            if animal.nombre == nombre_animal:
                return animal

    def cambiar_de_encargado_al_animal(self):
        nombre_animal = self.encontrar_animal(
            "Ingrese el nombre del animal a cambiar de encargado: ")
        if not nombre_animal:
            print("El animal no existe en la lista")
        else:
            opcion = input(
                "Para elegir encargado ya existente use \"1\", para crear uno nuevo \"2\": ")
            if opcion == "1":
                empleado_legajo = input(
                    "Ingrese el legajo del empleado: ")
                empleado_original = input(
                    "Ingrese el legajo del empleado que deja de cuidarlo: ")
                for encargado in self.lista_empleados:
                    if empleado_legajo == encargado.legajo:
                        nombre_animal.encargado_cuidar = encargado
                        encargado.lista_animales_a_cuidar.append(
                            nombre_animal)
                for encargado in self.lista_empleados:
                    if empleado_original == encargado:
                        encargado.lista_animales_a_cuidar.remove(
                            nombre_animal)
            elif opcion == "2":
                empleado_original = input(
                    "Ingrese el legajo del empleado que deja de cuidarlo: ")
                for encargado in self.lista_empleados:
                    if empleado_original == encargado:
                        encargado.lista_animales_a_cuidar.remove(
                            nombre_animal)
                empleado_nuevo = self.crear_encargado()
                nombre_animal.encargado_cuidar = empleado_nuevo
                empleado_nuevo.lista_animales_a_cuidar.append(
                    nombre_animal)
            else:
                print("Opcion incorrecta")

    def imprimir_lista_animales(self):
        print("----base animales----")
        for animal in self.lista_animales:
            for encargado in self.lista_empleados:
                if encargado == animal.encargado_cuidar:
                    print(
                        f"Nombre: {animal.nombre}\nTipo: {animal.tipo_animal}\nFecha de nacimiento: {animal.fecha_nacimiento}\nEncargado responsable: {encargado.nombre} Apellido: {encargado.apellido} Legajo: {encargado.legajo}")

    def imprimir_lista_empleados(self):
        print("----base empleados----")
        for empleado in self.lista_empleados:
            for animal in empleado.lista_animales_a_cuidar:
                print(
                    f"Nombre: {empleado.nombre}\nApellido: {empleado.apellido}\nLegajo: {empleado.legajo}\nLista de animales a cargo: {animal.nombre}")
