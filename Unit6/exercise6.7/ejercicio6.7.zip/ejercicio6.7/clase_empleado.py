from clase_animal import *


class Empleado:
    def __init__(self, legajo, nombre, apellido):
        self.legajo = legajo
        self.nombre = nombre
        self.apellido = apellido
        self.lista_animales_a_cuidar: list[Animal] = []

    def agregar_animal(self, animal_a_agregar):
        self.lista_animales_a_cuidar.append(animal_a_agregar)
